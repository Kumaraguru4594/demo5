package com.scb.spring.jpa.postgresql.model;

public enum PaymentStatus {
    ON_TIME,
    LATE,
    DEFAULTED
}
