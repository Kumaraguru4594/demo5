package com.scb.spring.jpa.postgresql.model;

public enum LoanType { SECURED, UNSECURED }
